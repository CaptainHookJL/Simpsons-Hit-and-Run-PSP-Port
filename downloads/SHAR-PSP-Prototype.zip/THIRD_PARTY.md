# Format reference

The new Python converter checks PC Pure3D binary structures against
[Hampo/LuaP3DLib](https://github.com/Hampo/LuaP3DLib) at
`7a9587a58cb56148db15ba5ffd882c76c144423f`, particularly Mesh,
OldPrimitiveGroup, PositionList, IndexList, and ColourList chunks.
Texture, Image, ImageData, Shader, ShaderTextureParameter, and UVList layouts
were also consulted for the texture sidecar converter.
Credits: Proddy (Lua implementation), Lucas Cardellini (chunk structures),
and EnAppelsin (original P3D Lua idea). The Lua runtime is not bundled.

Upstream license:

MIT License

Copyright (c) 2020 Proddy

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
